﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Brilliantech.Packaging.Store.UI
{
    public enum MsgLevel
    {
        Info = 0,
        Successful = 1,
        Warning = 2,
        Mistake = 3
    }
}
